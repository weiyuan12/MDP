# Algorithm

## Install Project Dependencies
```bash
pip install -r requirements.txt
```

## Run Project
```bash
python main.py
```
