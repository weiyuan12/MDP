from enum import Enum


class Direction(Enum):
    LEFT = 180
    RIGHT = 0
    TOP = 90
    BOTTOM = -90
