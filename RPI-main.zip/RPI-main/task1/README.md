## Task 1

```
In task 1: 
main.py: where multiprocessing will take place, run this file in week 8
bullseye.py: for testing the turn upon recognising the bullseye in the checklist
imageapi.py: connection with imageserver and functions
serialapi.py: connection to STM and functions
ipsocketapi: connection to pc/algo and functions
bluetoothapi.py: connection to bluetooth and functions
checklista1.py: program to clear checklist a1
```