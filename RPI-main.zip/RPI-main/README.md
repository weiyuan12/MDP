# RPI

This is the code to run on the RPI itself.
The code is separated into task1 and task2.
