import imagezmq
import cv2
import numpy as np
from ultralytics import YOLO
from multiprocessing import Process
from utils import *

# The `ImageProcessor` class is a Python class that processes and predicts images received from a
# Raspberry Pi using a YOLOv8 model.
class ImageProcessor:
    def __enter__(self):
            return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Clean up operations can be added here, if needed
        # For now, we will leave it empty as you didn't specify any
        pass

    def __init__(self, port='tcp://*:5555'):
        # Uncomment below if you want to load the model during initialization
        print("[PC] Loading model weights...")
        self.model = self.load_model()
        print("[PC] YoloV8 Model weights loaded!")
        self.port = port
        print("[PC] ImageHub Server running, ready to receive requests for Image API & make predictions!")

    def load_model(self):
        """
        Load the model from the local directory
        """
        # Get the current working directory
        current_directory = os.getcwd()
        
        # Check if it's in the root ImageRec directory
        if 'ImageRec' in current_directory and not current_directory.endswith('YoloV8 Inference Server'):
            model_path = os.path.join(current_directory, 'YoloV8 Inference Server', 'Weights', 'bestv2.pt')
        else:
            model_path = os.path.join(current_directory, 'Weights', 'bestv2.pt')

        # Load the model using the determined path
        model = YOLO(model_path)
        return model

    def receive_image(self, slug):
        try:
            rpi_name, image = self.image_hub.recv_image()
            filename = f'received_image_{slug}.jpg'  
            cv2.imwrite(filename, image)
            return rpi_name, image
        except Exception as e:
            print(f"Error: {e}")
            self.restart_image_hub()
            return None, None


    def restart_image_hub(self):
        time.sleep(1)
        self.image_hub.close()
        print("[PC] ImageHub Server closed, restarting...")
        self.image_hub = imagezmq.ImageHub(open_port='tcp://*:5555', REQ_REP=True)
        print("[PC] ImageHub Server restarted, ready to receive requests for Image API & make predictions!")

    def process_image(self, image, slug, alpha, beta):
            # image = cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)
            
            # kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
            # image = cv2.filter2D(image, -1, kernel)
            
            alpha = 1.1  # Slight increase in contrast
            beta = 20    # Slight increase in brightness
            image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
            
            # Convert the image to grayscale using OpenCV
            # image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # processed_filename = f'processed_image_{slug}.jpg'
            # cv2.imwrite(processed_filename, image)

            image_resized = cv2.resize(image, (416, 416))
            resized_filename = f'resized_image_{slug}.jpg'
            cv2.imwrite(resized_filename, image_resized)

            return image_resized

    # def process_image(self, image, slug, alpha=1.1, beta=20):
    #     """
    #     Process the image with optional parameters for contrast (alpha) and brightness (beta)
    #     """
    #     # alpha is the contrast control. Values greater than 1 increase the contrast.
    #     # beta is the brightness control. Positive values increase the brightness.
    #     image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
        
    #     kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    #     image = cv2.filter2D(image, -1, kernel)
        
    #     image_resized = cv2.resize(image, (416, 416))
    #     resized_filename = f'resized_image_{slug}.jpg'
    #     cv2.imwrite(resized_filename, image_resized)

    #     return image_resized

    def predict_image(self, image,slug):
        
        project_dir = "runs/detect"
        name_dir = f"predict{slug}"

        # To hide confidence of predictions

        # results = self.model(image, imgsz = 416, conf=0.2, save=True, show_conf=False, project=project_dir, name=name_dir)
        results = self.model(image, imgsz = 416, conf=0.2, save=True, show_conf=True, project=project_dir, name=name_dir)

        names = self.model.names
        # print("Printing names")
        # print(names)

        predicted_class = '99'
        max_prob = 0

        for result in results:
            confidences = result.boxes.conf  # Confidence scores of the detections
            classes = result.boxes.cls  # Class values of the detections
            print('Printing confidences')
            print(confidences)
            print('Printing classes')
            print(classes)

            for i, confidence in enumerate(confidences):
                print('Current confidence:', confidence)
                if confidence > max_prob:
                    max_prob = confidence
                    predicted_class = names[int(classes[i])]
                    print('Updated predicted_class:', predicted_class)
        
        return predicted_class

    # def run(self):
    #     self.image_hub = imagezmq.ImageHub(open_port=self.port, REQ_REP=True)
    #     while True:  
    #         print("[PC] Waiting for image from RPi...")
    #         slug = str(int(time.time()))  # Generate a unique slug based on the current timestamp
    #         rpi_name, image = self.receive_image(slug)  # receive image from RPi
    #         print(f"[PC] Received image from {rpi_name}")
    #         if image is not None:

    #             print('[PC] Processing image...')
    #             processed_image = self.process_image(image, slug)
    #             print('[PC] Image processed!')

    #             print('[PC] Predicting image...')
    #             image_id =  self.predict_image(processed_image,slug)  # make predictions here
    #             print('[PC] Image predicted!')

    #             # Move images after prediction
    #             base_dir = os.path.join(os.getcwd(), 'runs', 'detect')
    #             # filenames_with_slug = [f.replace('.jpg', f'_{slug}.jpg') for f in ['processed_image.jpg', 'received_image.jpg', 'resized_image.jpg']]
    #             filenames_with_slug = [f.replace('.jpg', f'_{slug}.jpg') for f in ['received_image.jpg', 'resized_image.jpg']]
    #             move_images_to_latest_directory(base_dir, filenames_with_slug)

    #             self.image_hub.send_reply(image_id.encode('utf-8'))  # reply to the RPi
    #             print(f"[PC] Sent image_id {image_id} to RPi") 
    
    def run(self):
        self.image_hub = imagezmq.ImageHub(open_port=self.port, REQ_REP=True)
        
        while True:  
            print("[PC] Waiting for image from RPi...")
            
            # Generate a unique slug based on the current timestamp
            slug = str(int(time.time()))
            
            # Receive image from RPi
            rpi_name, image = self.receive_image(slug)
            print(f"[PC] Received image from {rpi_name}")
            
            if image is not None:
                detection_attempts = 0
                successful_detection = False
                
                # Default values for alpha and beta
                alpha = 1.0
                beta = 0
                
                while detection_attempts < 3 and not successful_detection:
                    print('[PC] Processing image...')
                    
                    # If detection attempt failed previously, adjust alpha and beta
                    if detection_attempts > 0:
                        alpha += 0.1 # add 0.1 each time
                    
                    if detection_attempts == 1:
                        beta += 10 # first time add 10
                    elif detection_attempts == 2:
                        beta += 15 # second time add 15
                    
                    # Process the image with current alpha and beta
                    processed_image = self.process_image(image, slug, alpha, beta)
                    print(f'[PC] Image processed with alpha: {alpha} and beta: {beta}!')

                    print('[PC] Predicting image...')
                    
                    # Make prediction on the processed image
                    image_id = self.predict_image(processed_image, slug)
                    
                    # Check the prediction result
                    if image_id != '99':  # Assuming '99' means no detection
                        successful_detection = True
                        print('[PC] Image predicted!')
                    else:
                        detection_attempts += 1
                        print(f"[PC] Detection attempt {detection_attempts} failed, enhancing image.")
                
                # Move images after all prediction attempts or after a successful prediction
                base_dir = os.path.join(os.getcwd(), 'runs', 'detect')
                filenames_with_slug = [f.replace('.jpg', f'_{slug}.jpg') for f in ['received_image.jpg', 'resized_image.jpg']]
                move_images_to_latest_directory(base_dir, filenames_with_slug)
                
                # Send the appropriate reply to RPi
                if successful_detection:
                    self.image_hub.send_reply(image_id.encode('utf-8'))
                    print(f"[PC] Sent image_id {image_id} to RPi")
                else:
                    print("[PC] All attempts to detect the image failed. Sending '99' to RPi.")
                    self.image_hub.send_reply(image_id.encode('utf-8'))
                    print(f"[PC] Sent image_id {image_id} to RPi")


if __name__ == "__main__":
    with ImageProcessor() as processor:
        # Start the run method in a separate process
        process = Process(target=processor.run)
        process.start()

        while True:
            user_input = input("Do you want to end the process? (y/n): \n").strip().lower()
            if user_input in ['y', 'yes']:
                print("[PC] Stopping the Image Processor...")
                process.terminate()  # Terminate the process
                process.join()  # Wait for the process to finish
                print("[PC] Stitching Images...")
                stitch_images()  # Then, stitch the images
                print("[PC] Finished Stitching!")
                break

