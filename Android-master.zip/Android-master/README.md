# Android
Version: API 30 - Android 11.0 (R),
Support Galaxy Tab A7 Lite